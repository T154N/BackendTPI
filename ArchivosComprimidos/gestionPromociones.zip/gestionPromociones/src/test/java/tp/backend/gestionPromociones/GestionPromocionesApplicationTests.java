package tp.backend.gestionPromociones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionPromocionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
