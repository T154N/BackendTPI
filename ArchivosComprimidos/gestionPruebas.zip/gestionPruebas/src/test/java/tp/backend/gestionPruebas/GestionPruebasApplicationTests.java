package tp.backend.gestionPruebas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionPruebasApplicationTests {

	@Test
	void contextLoads() {
	}

}
