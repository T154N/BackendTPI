package tp.backend.gestionPruebas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionPruebasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionPruebasApplication.class, args);
	}

}
